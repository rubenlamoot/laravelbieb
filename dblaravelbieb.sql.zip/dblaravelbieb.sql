-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 05 apr 2019 om 09:55
-- Serverversie: 5.7.21
-- PHP-versie: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dblaravelbieb`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `addresses`
--

DROP TABLE IF EXISTS `addresses`;
CREATE TABLE IF NOT EXISTS `addresses` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `street` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `house_nr` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bus_nr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `addresses`
--

INSERT INTO `addresses` (`id`, `street`, `house_nr`, `bus_nr`, `postal_code`, `city`, `created_at`, `updated_at`) VALUES
(1, 'Brycen Square', '5471', NULL, '31491', 'Addieburgh', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(2, 'Ruecker Trail', '87513', NULL, '17699-2635', 'East Callie', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(3, 'Enos Junction', '433', NULL, '57552-0876', 'Haleyfurt', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(4, 'Labadie Trace', '8693', NULL, '18451', 'Lake Alford', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(5, 'Ryan Courts', '28218', NULL, '33312', 'Lake Shanna', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(6, 'Kloosterstraat', '5', NULL, '8647', 'Lo-Reninge', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(7, 'Testlaan', '1', NULL, '8000', 'Brugge', '2019-04-01 05:28:26', '2019-04-01 05:28:26');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `address_user`
--

DROP TABLE IF EXISTS `address_user`;
CREATE TABLE IF NOT EXISTS `address_user` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `address_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `address_user_user_id_index` (`user_id`),
  KEY `address_user_address_id_index` (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `address_user`
--

INSERT INTO `address_user` (`id`, `user_id`, `address_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL),
(2, 2, 2, NULL, NULL),
(3, 3, 3, NULL, NULL),
(4, 4, 4, NULL, NULL),
(5, 5, 5, NULL, NULL),
(6, 6, 6, NULL, NULL),
(7, 7, 7, NULL, NULL),
(8, 8, 7, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE IF NOT EXISTS `authors` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `authors`
--

INSERT INTO `authors` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Hertha Gutmann', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(2, 'Deion Huels', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(3, 'General Grady', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(4, 'Ms. Kamille Weber III', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(5, 'Ettie Morissette', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(6, 'Prof. Rebeca Doyle MD', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(7, 'Jerod Wyman', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(8, 'Deborah Doyle DDS', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(9, 'Elisa Ullrich', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(10, 'Rose Heidenreich', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(11, 'Donnie Murray', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(12, 'Dexter Cole', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(13, 'Trace Mann', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(14, 'Delphine Feeney', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(15, 'Wilbert Ondricka', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(16, 'Michael Johnson', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(17, 'Dr. Agustin Hoppe PhD', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(18, 'Mozelle Tremblay', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(19, 'Larue Klein II', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(20, 'Mr. Ansel Schiller III', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(21, 'Dan Brown', '2019-04-01 06:02:45', '2019-04-01 06:34:19');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE IF NOT EXISTS `books` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_id` int(10) UNSIGNED NOT NULL,
  `isbn` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` year(4) NOT NULL,
  `edition` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_id` int(10) UNSIGNED DEFAULT NULL,
  `aantal` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `books_author_id_index` (`author_id`),
  KEY `books_photo_id_index` (`photo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `books`
--

INSERT INTO `books` (`id`, `title`, `author_id`, `isbn`, `published`, `edition`, `description`, `photo_id`, `aantal`, `created_at`, `updated_at`) VALUES
(1, 'Animi nihil dolorum neque minima non sed distinctio eum.', 4, '9791623851551', 2007, '9e druk', 'Itaque eveniet et natus ex repudiandae suscipit quam. Repudiandae maxime iste aspernatur ut. Fuga vitae quae iusto quibusdam totam in est. Et qui dolore qui expedita dolorem eos est assumenda.', 1, 4, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(2, 'Et cumque eos magnam architecto dolores sequi.', 11, '9788523402136', 1981, '8e druk', 'Magni quis fugiat aliquid nam quo veritatis delectus. Laudantium aut aut illum pariatur ipsa. Aliquid natus quia non aut dignissimos qui. Non dolorum eum sapiente veniam sed minus consequatur.', 1, 8, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(3, 'Amet beatae commodi et et excepturi consequatur maiores.', 10, '9791132875765', 1989, '2e druk', 'Vero fugiat voluptatem quibusdam dicta quia quos dolore beatae. Voluptatem ullam repudiandae quas enim facere. Tempore est eum qui quam nihil vel. Laboriosam neque veritatis omnis.', 1, 5, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(4, 'Voluptas iure dignissimos accusamus ut quo quasi.', 16, '9789542392361', 1989, '6e druk', 'Dolores ut est quis minus est. Nihil voluptas enim cum. Consequatur totam atque optio qui id culpa rerum. Voluptas est doloremque dolor consequatur.', 1, 3, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(5, 'Voluptatem et voluptas omnis ratione non vero.', 1, '9780990782520', 1982, '2e druk', 'Explicabo rerum rerum sit dolores fugiat. Architecto sunt id adipisci vel dicta. Qui quis dolorem ut praesentium voluptates quaerat aut illo. Distinctio et est eaque sequi amet quia quisquam.', 1, 5, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(6, 'Expedita dignissimos id aliquam sint quia quidem.', 6, '9785244513288', 1985, '5e druk', 'Porro quod quia saepe sunt et ut. Ipsa aliquam reprehenderit assumenda recusandae. Dolor in culpa nostrum provident pariatur sit quae.', 1, 1, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(7, 'Dolor labore earum cumque.', 14, '9789833125425', 1987, '9e druk', 'Qui numquam magni odit dicta magni consequatur quam. Autem molestiae nesciunt vel suscipit hic. Sit molestias aperiam quos. Rerum adipisci iure beatae perferendis quos. At aliquid veniam consequatur.', 1, 2, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(8, 'Molestiae distinctio dignissimos dignissimos id numquam facilis rerum accusantium.', 5, '9788500852510', 1984, '4e druk', 'Corporis rem non velit assumenda sunt. Voluptatem nihil sit natus est laudantium voluptas non hic. Odit ut hic aliquam aut dolore placeat.', 1, 8, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(9, 'Totam quia ratione autem vel.', 8, '9796876540887', 2001, '5e druk', 'Doloremque officiis excepturi placeat cum suscipit omnis. Quia ratione necessitatibus voluptatem. Officia laudantium voluptatem sint rem omnis sunt perferendis. Est quas et corrupti sit numquam.', 1, 9, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(10, 'Id consequuntur culpa nobis enim accusantium optio voluptatibus.', 1, '9790305964794', 2003, '9e druk', 'Libero et quam non dolor ipsa est. Voluptatem doloremque quia omnis et suscipit et. Ratione et optio voluptatem. Harum aliquid nihil aperiam quisquam alias quo.', 1, 8, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(11, 'Ratione ut dolorem dolor voluptas architecto ea.', 7, '9789160974659', 2017, '9e druk', 'Pariatur eos voluptatibus sed quis. Aut molestiae quaerat eum non nostrum. Fuga laboriosam id neque velit repellat.', 1, 2, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(12, 'Omnis dolorem non nihil corporis.', 12, '9784772782678', 2013, '1e druk', 'Accusamus quis vel hic eveniet voluptatem. Tempora beatae consequatur aut. Cupiditate repellendus et ipsum placeat cumque. Tempora aperiam aut dignissimos harum beatae excepturi.', 1, 8, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(13, 'Nihil iure nobis beatae et.', 20, '9797173631827', 2007, '3e druk', 'Dolorum modi architecto nisi id voluptatibus. Repellendus rerum aut ea sint maxime ullam. Minima possimus iusto quia sed. Laudantium laboriosam voluptas eius vel aut est.', 1, 6, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(14, 'Qui voluptatem eos suscipit ipsum.', 19, '9794441195128', 2000, '7e druk', 'Voluptatem aut non laboriosam doloremque nemo error quia occaecati. Architecto voluptatem ad quibusdam. Aut sapiente ratione quod voluptas vero dolore voluptas ut.', 1, 4, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(15, 'Ut explicabo odio voluptatem.', 12, '9783574100864', 1980, '7e druk', 'Asperiores quibusdam qui sint dolores qui soluta error porro. Quidem consequatur itaque perspiciatis quas. Quia aut cum sed ullam nobis.', 1, 3, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(16, 'Necessitatibus sequi maiores quaerat vero.', 14, '9786964752315', 1982, '5e druk', 'Vitae in aut est corrupti vel. Voluptatibus quia est harum et voluptate optio. Nam qui sed pariatur dolor est voluptas. Dolorem molestiae accusamus quas minus.', 1, 3, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(17, 'Laboriosam rerum reiciendis nobis suscipit aut error.', 16, '9784565322807', 2006, '7e druk', 'Voluptatem unde non ea velit at harum. Ipsam autem nihil sunt odio quo.', 1, 8, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(18, 'Error mollitia alias et dignissimos eveniet blanditiis.', 1, '9786301079518', 2001, '1e druk', 'Voluptas architecto possimus eaque vel. Nobis sit repellendus veritatis nesciunt aut itaque. Quam blanditiis sit illum autem eum voluptas quam. Odit dolorum repellat sed sint nisi voluptas.', 1, 9, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(19, 'Vel necessitatibus quasi nam id possimus unde soluta.', 1, '9787931846693', 2017, '6e druk', 'Illo accusantium dolores harum. At provident ratione occaecati maxime perspiciatis. Recusandae voluptatem dolorem consequatur minima et. Aliquam dolorem eum consequatur omnis et.', 1, 4, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(20, 'Error a eos voluptatem quae qui.', 18, '9793641617119', 2000, '6e druk', 'Eos natus qui magni aut ea quidem rerum. Qui corporis sed minus non aspernatur excepturi. Tempora debitis fuga dolor et aperiam. Voluptatem est reprehenderit exercitationem accusantium quae debitis.', 1, 8, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(21, 'Nam ut sed porro voluptatibus.', 8, '9799541450955', 2014, '8e druk', 'Dolorem voluptates nisi quia minima quis ut. Harum molestiae molestiae unde consequatur. Voluptatem ullam voluptatibus quaerat dolores similique incidunt. Earum a consectetur omnis aliquid.', 1, 3, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(22, 'Iusto temporibus fugiat ipsa aut et voluptate.', 20, '9793547286006', 2015, '3e druk', 'Placeat culpa quia nobis quis explicabo. Sed numquam est id aliquid saepe. Et id sequi suscipit laborum sed.', 1, 6, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(23, 'Aliquid error accusantium aliquid.', 10, '9780196744865', 1990, '5e druk', 'Vel consequuntur ad possimus iusto veritatis sed mollitia rerum. Reprehenderit quo distinctio eos. Culpa non quod vel non iusto ipsum sit. Quo distinctio similique illo ducimus.', 1, 4, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(24, 'Exercitationem et rerum dicta blanditiis.', 16, '9782869214491', 1970, '5e druk', 'Et optio exercitationem rerum numquam. Sed nihil ut hic rerum molestiae autem. Quasi officiis neque dolorum voluptatibus.', 1, 3, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(25, 'Non molestiae voluptas dolore et voluptatem perspiciatis harum adipisci.', 18, '9794791395933', 1992, '7e druk', 'Rerum perferendis veniam qui alias. Explicabo tempora quia sint ex quos eveniet. Aspernatur voluptatem et architecto odit. Repellat sit animi consequuntur.', 1, 6, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(26, 'Provident dolor officiis voluptatem voluptatem.', 10, '9794644217535', 2010, '8e druk', 'Quas voluptatem deserunt delectus fugiat voluptatem molestiae. Quae facere corrupti officiis consequatur dolor. Culpa vel sed ullam ad.', 1, 8, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(27, 'Sunt sit deserunt repudiandae architecto incidunt at et.', 9, '9789566388050', 1976, '6e druk', 'Qui eveniet accusantium quae. Enim quam culpa recusandae sed magnam et.', 1, 3, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(28, 'Recusandae ullam asperiores rerum et et eos.', 4, '9783080649086', 1990, '5e druk', 'Voluptas quis assumenda adipisci quia. Sed deleniti non similique alias ea. Nihil sequi nobis optio velit. Sit iste et quaerat.', 1, 3, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(29, 'Dicta qui repellat eligendi voluptatem nam suscipit rem.', 14, '9796667646330', 1992, '8e druk', 'Repudiandae natus eius ad dolorum enim. In neque illum et ea non. Sapiente incidunt voluptates nihil.', 1, 7, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(30, 'Et recusandae exercitationem quidem id.', 6, '9790714486306', 1982, '4e druk', 'Eos sunt et tempora nisi non. Eius odio non provident dolor odit eligendi. Repellat cum cum voluptatibus optio officia et sapiente harum. Quo delectus necessitatibus ea illum ad distinctio.', 1, 6, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(31, 'Soluta aut commodi recusandae dolores et et voluptas.', 6, '9790574509092', 2005, '6e druk', 'Sapiente consectetur voluptatem dolore libero qui rerum. Dolores rerum quam omnis vel.', 1, 4, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(32, 'Minus officiis mollitia est ratione sit nostrum.', 15, '9797145269553', 1991, '4e druk', 'Eum reiciendis consequuntur consequatur voluptatem est. Nisi quia molestiae sunt placeat et. Ut asperiores veniam libero quo mollitia sed. Consequuntur non et harum vel vel pariatur impedit.', 1, 4, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(33, 'Consequatur similique porro est quis quis ea.', 9, '9792978928042', 2007, '8e druk', 'Dolorem voluptate cupiditate consequatur asperiores. Qui et consequatur enim qui ut.', 1, 8, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(34, 'Quia reprehenderit omnis possimus aliquid et.', 2, '9794908453952', 2007, '3e druk', 'Sint animi eos ipsa sit explicabo rerum. Ut labore vel placeat veniam.', 1, 7, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(35, 'Qui ut voluptatibus explicabo id porro sed.', 5, '9791782107322', 2000, '4e druk', 'Quia debitis et recusandae officiis. Ex tempore magni quaerat reprehenderit. Quo quo eum sint perspiciatis praesentium reiciendis. Error nobis reiciendis cumque quia voluptas.', 1, 5, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(36, 'Eius sint itaque odit veritatis soluta.', 9, '9799052827765', 2017, '3e druk', 'Eum sunt consequatur maxime omnis facere sit repellendus voluptates. Autem a dolor nihil molestiae. Qui ratione omnis quisquam deleniti vitae. Repellat mollitia maiores suscipit quia fugit eum.', 1, 1, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(37, 'Eaque incidunt quasi sit ullam.', 6, '9798801116464', 1971, '9e druk', 'Neque dolorum error quod hic quo quo amet aut. Voluptate incidunt architecto corrupti fugiat dignissimos. Quo quis tempore corrupti rerum hic iure libero. Est quia ab est aut.', 1, 2, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(38, 'Voluptatum consequatur atque perspiciatis laudantium sint.', 1, '9798766330073', 1995, '6e druk', 'Corrupti et consectetur facilis ab voluptas molestiae illum. Ratione exercitationem occaecati et non. Modi autem eius error. Dicta tempore mollitia dolores voluptates explicabo.', 1, 3, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(39, 'Ut in assumenda quos provident atque.', 6, '9791084320955', 2014, '3e druk', 'Laudantium nostrum illo perferendis est animi voluptas non. Debitis dolores quo aliquam deserunt in sint commodi.', 1, 5, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(40, 'Eius consequatur nemo ducimus qui.', 16, '9796895453755', 2016, '5e druk', 'Quaerat optio et qui inventore ut. Quis officiis saepe vel aut sed.', 1, 9, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(41, 'Quia modi minima aliquid placeat soluta rerum.', 9, '9789948346326', 1973, '1e druk', 'Quam occaecati sit praesentium repellendus. Et ad mollitia ut est architecto error dignissimos. Qui qui impedit rerum voluptates rem tempore. Quaerat atque eaque beatae sunt unde.', 1, 8, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(42, 'Voluptas beatae aut accusamus eos.', 6, '9788185852577', 1983, '9e druk', 'Ut perferendis odio animi quos est. Ea suscipit ut non amet perferendis. Aliquid a quasi et quas ad error qui hic.', 1, 6, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(43, 'Porro a sequi soluta aperiam.', 15, '9796258502885', 2015, '7e druk', 'Dolorem quod harum impedit. Rerum enim et modi voluptate facere autem accusamus. Nemo recusandae omnis voluptatum fuga. Modi inventore cupiditate iusto excepturi.', 1, 4, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(44, 'Ab neque aut rem ut voluptatum maxime et.', 10, '9783870581268', 1979, '5e druk', 'Similique optio in enim cumque aut consectetur. Officiis nam maiores ut nam molestiae labore. Dolores officia autem error vel culpa voluptatem. Rerum illo ut et natus laborum molestiae officiis.', 1, 2, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(45, 'Consequatur magnam voluptas ut.', 16, '9790739724728', 2001, '5e druk', 'Quasi officiis id officia voluptas in aut. Et ut amet voluptatum eum id quia. Qui commodi nisi et quis sequi possimus. Rerum quae culpa distinctio ab provident.', 1, 7, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(46, 'Laborum reprehenderit similique vitae est et sapiente occaecati dolorem.', 9, '9786570963068', 1985, '4e druk', 'Eligendi vel omnis ipsa id autem. Velit laboriosam non suscipit sapiente. Iure recusandae deserunt mollitia dolor rerum animi. Dignissimos omnis magni laudantium.', 1, 1, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(47, 'Quis sunt reiciendis ex iusto deserunt officiis.', 2, '9786183461463', 1990, '2e druk', 'Sit quo ut consequatur fugit. Eaque dicta aspernatur omnis illum assumenda. Iure iste et ut. Dignissimos quia consectetur eius qui totam architecto voluptatem.', 1, 4, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(48, 'Quidem voluptas vel voluptatem quo sint at perferendis.', 16, '9793238873317', 2011, '5e druk', 'Sunt minima corrupti facere enim. Dolores dolorem officia beatae est earum. Soluta autem laborum at corrupti similique facere. Cumque laborum maiores fugit aliquid.', 1, 7, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(49, 'Voluptas est vel laboriosam libero.', 16, '9786384099380', 2007, '9e druk', 'Vitae dolorum iure quis et assumenda. Qui et sint fugiat dolorem recusandae fugiat. Corrupti fugit et adipisci.', 1, 2, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(50, 'Nulla quasi rerum nesciunt impedit consequuntur.', 11, '9793389535409', 2016, '4e druk', 'Laudantium ex qui at expedita et. Et error et et aliquid veniam. Dolor voluptates dignissimos optio. Ut veniam laborum occaecati sequi dolorem sit.', 1, 1, '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(51, 'The DavinciCode', 21, '9789614677850', 2002, '3e druk', 'Spannende thriller met theologische inslag.', 2, 3, '2019-04-03 05:42:21', '2019-04-03 05:42:21'),
(52, 'Angels & Demons', 21, '9789614671149', 2008, '3e druk', 'Spannende thriller over van alles en nog wat.', 3, 6, '2019-04-05 06:06:29', '2019-04-05 06:06:29'),
(53, 'Deception Point', 21, '9789614672245', 1998, '6e druk', 'Thriller over wetenschap en de NASA waar niets lijkt wat het is.', 4, 10, '2019-04-05 06:22:25', '2019-04-05 06:53:46'),
(54, 'How to study smart', 9, '9789614672233', 2015, '1e druk', 'Boekje over bla bla', 6, 2, '2019-04-05 06:57:04', '2019-04-05 06:57:41'),
(55, 'Harry Potter', 13, '9789614679852', 1996, '4e druk', 'Boek over tovenaar Harry Potter.', 8, 4, '2019-04-05 07:05:29', '2019-04-05 07:05:29'),
(56, 'The Crow Girl', 12, '9754214677850', 2018, '4e druk', 'Boek over een meisje en een kraai.', 9, 2, '2019-04-05 07:15:26', '2019-04-05 07:15:26');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_03_21_105041_create_roles_table', 1),
(4, '2019_03_21_132140_create_books_table', 1),
(5, '2019_03_23_150724_create_authors_table', 1),
(6, '2019_03_24_131411_create_addresses_table', 1),
(7, '2019_03_26_141446_create_address_user_table', 1),
(8, '2019_03_29_095709_create_photos_table', 1),
(9, '2019_04_01_085559_create_rentals_table', 2);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `filename` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `photos`
--

INSERT INTO `photos` (`id`, `filename`, `created_at`, `updated_at`) VALUES
(1, '1553857068ReusDeZomerflat.jpg', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(2, '1554277341davinciCode.jpeg', '2019-04-03 05:42:21', '2019-04-03 05:42:21'),
(3, '1554451589AngelsDemons.jpeg', '2019-04-05 06:06:29', '2019-04-05 06:06:29'),
(4, '1554452545deceptionPoint.jpeg', '2019-04-05 06:22:25', '2019-04-05 06:22:25'),
(5, '1554454534Smart.jpeg', '2019-04-05 06:55:34', '2019-04-05 06:55:34'),
(6, '1554454624Smart.jpeg', '2019-04-05 06:57:04', '2019-04-05 06:57:04'),
(7, '1554454764Potter.jpeg', '2019-04-05 06:59:24', '2019-04-05 06:59:24'),
(8, '1554455129Potter.jpeg', '2019-04-05 07:05:29', '2019-04-05 07:05:29'),
(9, '1554455726CrowGirl.jpeg', '2019-04-05 07:15:26', '2019-04-05 07:15:26');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `rentals`
--

DROP TABLE IF EXISTS `rentals`;
CREATE TABLE IF NOT EXISTS `rentals` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `book_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `book_out` date NOT NULL,
  `book_in` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rentals_book_id_index` (`book_id`),
  KEY `rentals_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `rentals`
--

INSERT INTO `rentals` (`id`, `book_id`, `user_id`, `book_out`, `book_in`, `created_at`, `updated_at`) VALUES
(1, 7, 7, '2019-04-01', '2019-04-01', '2019-04-01 07:56:05', '2019-04-01 12:04:38'),
(2, 15, 7, '2019-03-01', '2019-04-04', '2019-04-01 10:14:08', '2019-04-04 11:09:40'),
(3, 6, 7, '2019-04-01', NULL, '2019-04-01 10:54:10', '2019-04-01 10:54:10'),
(4, 5, 7, '2019-04-01', '2019-04-04', '2019-04-01 10:54:24', '2019-04-04 11:34:21'),
(5, 9, 7, '2019-04-01', '2019-04-04', '2019-04-01 10:54:37', '2019-04-04 11:25:56'),
(6, 40, 7, '2019-04-01', '2019-04-04', '2019-04-01 10:54:47', '2019-04-04 10:44:01'),
(7, 15, 7, '2019-04-01', '2019-04-04', '2019-04-01 10:55:08', '2019-04-04 11:06:07'),
(8, 33, 7, '2019-04-03', NULL, '2019-04-03 05:26:21', '2019-04-03 05:26:21'),
(9, 51, 2, '2019-04-03', NULL, '2019-04-03 05:42:48', '2019-04-03 05:42:48'),
(10, 51, 1, '2019-03-03', NULL, '2019-04-03 05:43:01', '2019-04-03 05:43:01'),
(11, 51, 5, '2019-04-03', NULL, '2019-04-03 05:43:11', '2019-04-03 05:43:11'),
(12, 32, 7, '2019-04-04', NULL, '2019-04-04 10:51:42', '2019-04-04 10:51:42'),
(13, 30, 7, '2019-04-04', NULL, '2019-04-04 11:07:47', '2019-04-04 11:07:47'),
(14, 20, 7, '2019-04-04', NULL, '2019-04-04 11:33:46', '2019-04-04 11:33:46'),
(15, 31, 6, '2019-04-05', NULL, '2019-04-05 05:32:43', '2019-04-05 05:32:43');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Bibliothecaris', NULL, NULL),
(2, 'Ontlener', NULL, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `insurance_nr` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL DEFAULT '2',
  `is_active` int(11) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_id_index` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `first_name`, `last_name`, `insurance_nr`, `role_id`, `is_active`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Trace Schmeler', 'osenger@example.net', '2019-04-01 05:28:26', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Misty', 'Rowe', '07040737210', 2, 1, 'zlzhs79p6e', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(2, 'Marianna White', 'lbergstrom@example.org', '2019-04-01 05:28:26', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Lupe', 'Wolff', '56010273005', 2, 1, 'H1RtoBIRT8', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(3, 'Janelle Schmeler', 'jessica19@example.com', '2019-04-01 05:28:26', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Aliza', 'Bergnaum', '09101630783', 2, 1, 'P8pzQ6w06r', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(4, 'Kayleigh Davis', 'pleuschke@example.net', '2019-04-01 05:28:26', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Wilton', 'Rau', '74031737709', 2, 1, 'Wlzcdb9vH4', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(5, 'Gianni Lakin', 'ora.hickle@example.net', '2019-04-01 05:28:26', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Jayne', 'Steuber', '05021086253', 2, 1, 'QjVhQufsD8', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(6, 'Ruben Lamoot', 'rubenlamoot@gmail.com', NULL, '$2y$10$N3afUBVKnk96OwQ1bOuDPu/PoLhD94GItpCYLhfYCO7weCO/gz.Fa', 'Ruben', 'Lamoot', '76012601928', 1, 1, 'YnBKzJglg4MlGuNpW6EpEe0ypbCmtyIDCkH8imNaHtyTBzQwVaZJjZbifKof', '2019-04-01 05:28:26', '2019-04-01 05:28:26'),
(7, 'Test1', 'test1@gmail.com', NULL, '$2y$10$oiXl1avQhfqdNqY.8xWijuNstexeYrxqGFRTbbnFkqUxR12Gn5hT6', 'Test1', 'Tester1', '80022278514', 2, 0, 'raDJyzh1sRbuVdqVp0791UtAH7eobDusxZOlILJzHHvmRrRCjHp9We2363f9', '2019-04-01 05:28:26', '2019-04-05 07:21:13'),
(8, 'Test2', 'test2@gmail.com', NULL, '$2y$10$qHpbtGIg5vzymaqdtaKcBO3AJWyDskas7rrC7bcx8jqlehE5LbhZS', 'Test2', 'Tester2', '84022201845', 2, 1, NULL, '2019-04-05 07:37:55', '2019-04-05 07:37:55');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
